package org.makerminds.intership.restaurantpoint.controller;

import org.makerminds.intership.restaurantpoint.dataprovider.UserDataProvider;
import org.makerminds.intership.restaurantpoint.model.User;

public class LoginController {

	private static final LoginController INSTANCE = new LoginController();

	private UserDataProvider userDataProvider = new UserDataProvider();
	private User loggedInUser = null;

	private LoginController() {

	}

	public void logInUser(String username, String password) {
		for (User user : userDataProvider.getUserList()) {
			if (user.getUsername().equals(username) && user.getPassword().equals(password)) {
				loggedInUser = user;
			}
		}
	}

	public User getLogginUser() {
		return loggedInUser;

	}

	public static LoginController getInstance() {
		return INSTANCE;
	}

	public boolean isStringNullOrBlank(String value) {
		return value == null || value.isBlank();

	}

}