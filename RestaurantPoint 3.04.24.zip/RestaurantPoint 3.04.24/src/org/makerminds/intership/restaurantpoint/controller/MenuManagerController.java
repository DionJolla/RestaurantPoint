package org.makerminds.intership.restaurantpoint.controller;

public class MenuManagerController {

	
	// tek controllers te duhet
		// MenuManagerController
		// Add new menu, delete a menu, update a menu
		//MenuItemManager
		// add, update delete menu item or product 
		//REstaurantManager 
	
	//CRUD operations per secilin objekt psh Restaurante menu, menuites edhe table qe menaxhohen prej kontrollers. 
	// po shpresoj qe  epart e se kam kompliku 


}
