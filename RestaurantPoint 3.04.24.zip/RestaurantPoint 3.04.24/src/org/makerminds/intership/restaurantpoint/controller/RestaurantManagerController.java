package org.makerminds.intership.restaurantpoint.controller;

import java.util.Iterator;
import java.util.List;

import org.makerminds.intership.restaurantpoint.dataprovider.DataProvider;
import org.makerminds.intership.restaurantpoint.model.Restaurant;

public class RestaurantManagerController {

	private Restaurant createRestaurant(String[] restaurantData) {
		String name = restaurantData[0];
		String address = restaurantData[1];
		return new Restaurant(name, address, null, null);
	}
//qito mundesi i bon jo statike
	public void addRestaurant(Restaurant selectedRestaurant, String[] restaurantData) {
		Restaurant newRestaurant = createRestaurant(restaurantData);
		// restaurant.getRestaurantList().add(newRestaurant);
		// dmth e krijon nje objekt pastaj  i thrret metodad 
		DataProvider.getRestaurantList().add(newRestaurant);
	}

	public void updateRestaurant(Restaurant selectedRestaurant, String name, String[] restaurantData) {
		List<Restaurant> restaurantList = DataProvider.getRestaurantList();
		for (Restaurant restaurant : restaurantList) {
			if (restaurant.getName().equals(name)) {
				restaurant.setName(restaurantData[0]);
			}
		}

		//DataProvider.setRestaurantList(restaurantList);
	}

	public void deleteRestaurant(Restaurant selectedRestaurant, String name) {
		List<Restaurant> restaurantList = DataProvider.getRestaurantList();
		Iterator<Restaurant> iterator = restaurantList.iterator();
		while (iterator.hasNext()) {
			Restaurant restaurant = iterator.next();
			if (restaurant.getName().equals(name)) {
				iterator.remove();
			}
		}

	}
}
