package org.makerminds.intership.restaurantpoint.controller.database;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class JDBConnection {

	private String url = "jdbc:postgresql://localhost:5433/intershipjava";
	private String username = "postgres";
	private String password = "123";

	public Connection getConnection() throws ClassNotFoundException,SQLException {

		Connection connection = null;
		Class.forName("org.postgresql.Driver");
		connection = DriverManager.getConnection(url,username,password);
		return connection;
	}


}
