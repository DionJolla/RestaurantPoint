package org.makerminds.intership.restaurantpoint.controller.database;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class TableStructureProvider {

	private JDBConnection jdbConnection = new JDBConnection();
	private Connection connection;

	public void createTables() throws ClassNotFoundException,SQLException {
		connection = jdbConnection.getConnection();
		String createDepartmentTable = "CREATE TABLE IF NOT EXISTS departments(id SERIAL PRIMARY KEY,name VARCHAR(20))";
		PreparedStatement preparedStatment = connection.prepareStatement(createDepartmentTable);
		preparedStatment.executeUpdate();
		}

}
