package org.makerminds.intership.restaurantpoint.dataprovider;

import java.util.ArrayList;
import java.util.List;

import org.makerminds.intership.restaurantpoint.model.Category;
import org.makerminds.intership.restaurantpoint.model.Menu;
import org.makerminds.intership.restaurantpoint.model.Product;
import org.makerminds.intership.restaurantpoint.model.Restaurant;
import org.makerminds.intership.restaurantpoint.model.Table;

public class DataProvider {

	private  List<Restaurant> restaurantList;

	public DataProvider() {
		restaurantList = new ArrayList<>();
		createRestaurantList();
	}

	private  void createRestaurantList() {
		restaurantList.add(
				new Restaurant("Plaza", "Rruga e Elbasanit,Tirane", createMenuList(), createTableListForRestaurant()));
		restaurantList.add(new Restaurant("Taverna GOTA", "Sheshi i Qytetit,Mitrovice", createMenuList(),
				createTableListForRestaurant()));
	}

	public static  List<Menu> createMenuList() {
		List<Menu> menuList = new ArrayList<>();

		Menu menu1 = new Menu("1", "Menu e Mengjesit", createProductList1());
		menuList.add(menu1);
		Menu menu2 = new Menu("2", "Menu e Drekes", createProductList2());
		menuList.add(menu2);
		Menu menu3 = new Menu("3", "Menu e Mbremjes", createProductList2());
		menuList.add(menu3);

		return menuList;
	}

	public List<Restaurant> getRestaurantList() {
		return restaurantList;
	}

	public void setRestaurantList(List<Restaurant> restaurantList) {
		this.restaurantList = restaurantList;
	}

	private static List<Product> createProductList1() {
		List<Product> productList1 = new ArrayList<>();
		Product product1 = new Product(1, "Product 1", Category.MEAL);
		productList1.add(product1);
		Product product2 = new Product(2, "Product 2", Category.MEAL);
		productList1.add(product2);
		Product product3 = new Product(3, "Product 3", Category.DRINK);
		productList1.add(product3);

		return productList1;
	}

	private static List<Product> createProductList2() {
		List<Product> productList2 = new ArrayList<>();
		Product product1 = new Product(4, "Product 4", Category.MEAL);
		productList2.add(product1);
		Product product2 = new Product(5, "Product 5", Category.MEAL);
		productList2.add(product2);
		Product product3 = new Product(6, "Product 6", Category.DRINK);
		productList2.add(product3);

		return productList2;
	}

	private static List<Table> createTableListForRestaurant() {
		List<Table> tableList = new ArrayList<>();

		Table table1 = new Table(1, 4);
		tableList.add(table1);
		Table table2 = new Table(2, 6);
		tableList.add(table2);
		Table table3 = new Table(3, 8);
		tableList.add(table3);
		Table table4 = new Table(4, 4);
		tableList.add(table4);
		Table table5 = new Table(5, 12);
		tableList.add(table5);

		return tableList;

	}

}