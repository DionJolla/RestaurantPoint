package org.makerminds.intership.restaurantpoint.dataprovider;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.makerminds.intership.restaurantpoint.controller.database.JDBConnection;
import org.makerminds.intership.restaurantpoint.model.Menu;
import org.makerminds.intership.restaurantpoint.model.Restaurant;

public class DataProviderDatabase {

	private JDBConnection jdbConnection = new JDBConnection();
	private Connection connection;
	private List<Restaurant> restaurantList;
	private List<Menu> menuList;

	public List <Restaurant> getRestaurantList() throws SQLException,ClassNotFoundException {
		restaurantList = new ArrayList<>();
		connection = jdbConnection.getConnection();
		String getRestaurant = "SELECT * FROM Restaurant";
		PreparedStatement preparedStatement = connection.prepareStatement(getRestaurant);
		ResultSet resultSet = preparedStatement.executeQuery();


		while(resultSet.next()) {
			int restaurantId = Integer.valueOf(resultSet.getString("id"));
			String RestaurantName = resultSet.getString("name");
			//Restaurant.add(new Restaurant(menuList,restaurantList,new ArrayList<>()));

		}
		return restaurantList;
	}

}
