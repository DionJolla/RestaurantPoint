package org.makerminds.intership.restaurantpoint.dataprovider;

import java.util.ArrayList;
import java.util.List;

import org.makerminds.intership.restaurantpoint.model.User;
import org.makerminds.intership.restaurantpoint.model.UserRole;

public class UserDataProvider {
	private List<User> userList = new ArrayList<>();

	public UserDataProvider() {
		userList.add(new User("User1", "test123", UserRole.ADMIN));
		userList.add(new User("User2", "test456", UserRole.WAITER));
		userList.add(new User("User3", "test789", UserRole.COOK));
	}

	public List<User> getUserList() {
		return userList;
	}
}
