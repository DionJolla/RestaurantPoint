package org.makerminds.intership.restaurantpoint.model;

public enum Category {
	MEAL, DRINK
}