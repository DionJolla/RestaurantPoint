package org.makerminds.intership.restaurantpoint.model;

import java.util.ArrayList;
import java.util.List;

public class Employee {

	private String name;
	private String address;
	private String email;
	private String phoneNumber;
	private List<Task> taskList = new ArrayList<>();

	public Employee(String name, String address, String email, String phoneNumber, List<Task> taskList) {
		this.name = name;
		this.address = address;
		this.email = email;
		this.phoneNumber = phoneNumber;
		this.taskList = taskList;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getPhoneNumber() {
		return phoneNumber;
	}

	public void setPhoneNumber(String phoneNumber) {
		this.phoneNumber = phoneNumber;
	}

	public List<Task> getTaskList() {
		return taskList;
	}

	public void setTaskList(List<Task> taskList) {
		this.taskList = taskList;
	}

	@Override
	public String toString() {
		return name;
	}
}
