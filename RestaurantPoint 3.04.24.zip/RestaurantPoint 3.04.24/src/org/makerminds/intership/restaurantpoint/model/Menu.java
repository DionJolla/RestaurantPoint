package org.makerminds.intership.restaurantpoint.model;

import java.util.ArrayList;
import java.util.List;

public class Menu {
	private String menuNumber;
	private String menuDescription;
	private List<Product> productList = new ArrayList<>();

	public Menu(String menuNumber, String menuDescription, List<Product> productList) {
		this.menuNumber = menuNumber;
		this.menuDescription = menuDescription;
		this.productList = productList;
	}

	public String getMenuNumber() {
		return menuNumber;
	}

	public void setMenuNumber(String menuNumber) {
		this.menuNumber = menuNumber;
	}

	public String getMenuDescription() {
		return menuDescription;
	}

	public void setMenuDescription(String menuDescription) {
		this.menuDescription = menuDescription;
	}

	public List<Product> getProductList() {
		return productList;
	}

	public void setProductList(List<Product> productList) {
		this.productList = productList;
	}

}
