package org.makerminds.intership.restaurantpoint.model;

public class Product {
	private int productId;
	private String productName;
	private Category category;

	public Product(int productId, String productName, Category category) {
		this.productId = productId;
		this.productName = productName;
		this.category = category;
	}

	public int getProductId() {
		return productId;
	}

	public void setProductId(int productId) {
		this.productId = productId;
	}

	public String getProductName() {
		return productName;
	}

	public void setProductName(String productName) {
		this.productName = productName;
	}

	public Category getCategory() {
		return category;
	}

	public void setCategory(Category productCategory) {
		this.category = productCategory;
	}

}
