package org.makerminds.intership.restaurantpoint.model;

import java.util.ArrayList;
import java.util.List;

public class Restaurant {

	private String name;
	private String location;
	private List<Menu> menus = new ArrayList<>();
	private List<Table> tables;

	public Restaurant(String name, String location) {
		this.name = name;
		this.location = location;
		this.menus = new ArrayList<>();
		this.tables = new ArrayList<>();
	}

	public Restaurant(String name, String location, List<Menu> menuList,
			List<Table> tableListForRestaurant) {
		this.name = name;
		this.location = location;
		this.menus = menuList;
		this.tables = tableListForRestaurant;
	}


	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getLocation() {
		return location;
	}

	public void setLocation(String location) {
		this.location = location;
	}

	public List<Menu> getMenus() {
		return menus;
	}

	public void setMenus(List<Menu> menus) {
		this.menus = menus;
	}

	public List<Table> getTables() {
		return tables;
	}

	public void setTables(List<Table> tables) {
		this.tables = tables;
	}


	public String getAddress() {
		// TODO Auto-generated method stub
		return location;
	}
	// nje metode to string duhet qitu
}