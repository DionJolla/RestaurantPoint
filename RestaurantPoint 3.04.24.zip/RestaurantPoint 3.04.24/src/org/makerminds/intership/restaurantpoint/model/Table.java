package org.makerminds.intership.restaurantpoint.model;

public class Table {
	private int TableNumber;
	private int seats;
	private boolean isAvailable;

	public Table(int TableNumber, int seats) {
		this.TableNumber = TableNumber;
		this.seats = seats;
		this.isAvailable = true;
	}

	public int getTableNumber() {
		return TableNumber;
	}

	public void setTableNumber(int tableNumber) {
		this.TableNumber = tableNumber;
	}

	public int getSeats() {
		return seats;
	}

	public void setSeats(int seats) {
		this.seats = seats;
	}

	public boolean isAvailable() {
		return isAvailable;
	}

	public void setAvailable(boolean available) {
		isAvailable = available;
	}
}