package org.makerminds.intership.restaurantpoint.model;

public class Task {

	private String taskName;
	private String description;
	private TaskPriority taskPriority;

	public Task(String taskName, String description, TaskPriority taskPriority) {

		this.taskName = taskName;
		this.description = description;
		this.taskPriority = taskPriority;
	}

	public String getTaskName() {
		return taskName;
	}

	public void setTaskName(String taskName) {
		this.taskName = taskName;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public TaskPriority getTaskPriority() {
		return taskPriority;
	}

	public void setTaskPriority(TaskPriority taskPriority) {
		this.taskPriority = taskPriority;
	}

}
