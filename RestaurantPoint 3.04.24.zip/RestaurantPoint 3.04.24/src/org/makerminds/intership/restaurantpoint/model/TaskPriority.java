package org.makerminds.intership.restaurantpoint.model;

public enum TaskPriority {

	HIGH, LOW

}
