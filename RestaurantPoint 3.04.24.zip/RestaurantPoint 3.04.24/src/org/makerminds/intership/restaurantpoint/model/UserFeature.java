package org.makerminds.intership.restaurantpoint.model;

public enum UserFeature {
	RESTAURANT_MANAGER, MENU_MANAGER, MENU_ITEM_MANAGER, TABLE_MANAGER, TABLE_ORDERS, ORDERS_STATUS, ORDERS, SIGN_OUT

}
