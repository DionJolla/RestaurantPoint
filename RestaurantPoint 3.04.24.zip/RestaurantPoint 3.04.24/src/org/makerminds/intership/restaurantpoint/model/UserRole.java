package org.makerminds.intership.restaurantpoint.model;

public enum UserRole {
	ADMIN, WAITER, COOK
}
