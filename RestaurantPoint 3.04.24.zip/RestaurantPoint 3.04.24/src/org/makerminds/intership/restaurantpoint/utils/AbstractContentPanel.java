package org.makerminds.intership.restaurantpoint.utils;

import javax.swing.JPanel;

import org.makerminds.intership.restaurantpoint.view.IView;

public abstract class AbstractContentPanel  implements IView {

	public JPanel createContentPanel() {
		JPanel contentPanel = new JPanel();
		contentPanel.setLayout(null);
		contentPanel.setBounds(250,0,700,500);
		return contentPanel;


	}

}
