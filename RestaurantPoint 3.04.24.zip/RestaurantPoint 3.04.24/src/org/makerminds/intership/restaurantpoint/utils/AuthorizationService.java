package org.makerminds.intership.restaurantpoint.utils;

import java.util.Arrays;
import java.util.List;

import org.makerminds.intership.restaurantpoint.model.UserFeature;
import org.makerminds.intership.restaurantpoint.model.UserRole;

public class AuthorizationService {
	public List<UserFeature> getUserFeatureByUserRole(UserRole userRole) {
		switch (userRole) {
		case ADMIN: {
			return Arrays.asList(UserFeature.RESTAURANT_MANAGER, UserFeature.MENU_MANAGER,
					UserFeature.MENU_ITEM_MANAGER, UserFeature.TABLE_MANAGER, UserFeature.SIGN_OUT);
		}
		case WAITER: {
			return Arrays.asList(UserFeature.TABLE_ORDERS, UserFeature.ORDERS_STATUS, UserFeature.SIGN_OUT);
		}
		case COOK: {
			return Arrays.asList(UserFeature.ORDERS, UserFeature.SIGN_OUT);
		}
		default:
			throw new IllegalArgumentException("Unexpected value " + userRole);
		}
	}
}
