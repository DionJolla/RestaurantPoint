package org.makerminds.intership.restaurantpoint.utils;

import java.util.HashMap;
import java.util.Map;

import org.makerminds.intership.restaurantpoint.model.UserFeature;

public class UserFeatureLabelResolver {

	private static Map<UserFeature, String> userFeatureLabelMap;

	private static Map<UserFeature, String> createUserFeatureLabelMap() {
		if (userFeatureLabelMap == null) {
			userFeatureLabelMap = new HashMap<>();
			userFeatureLabelMap.put(UserFeature.MENU_ITEM_MANAGER, "Menu item manager");
			userFeatureLabelMap.put(UserFeature.MENU_MANAGER, "Menu manager");
			userFeatureLabelMap.put(UserFeature.ORDERS, "Orders");
			userFeatureLabelMap.put(UserFeature.ORDERS_STATUS, "Orders status");
			userFeatureLabelMap.put(UserFeature.RESTAURANT_MANAGER, "Restaurant manager");
			userFeatureLabelMap.put(UserFeature.TABLE_MANAGER, "Table manager");
			userFeatureLabelMap.put(UserFeature.TABLE_ORDERS, "Table orders");
			userFeatureLabelMap.put(UserFeature.SIGN_OUT, "Sign out");
		}

		return userFeatureLabelMap;
	}

	public static String getUserFeatureLabelResolver(UserFeature userFeature) {
		return createUserFeatureLabelMap().get(userFeature);

}
}
