package org.makerminds.intership.restaurantpoint.utils;

import java.util.HashMap;
import java.util.Map;

import org.makerminds.intership.restaurantpoint.model.UserFeature;
import org.makerminds.intership.restaurantpoint.view.ContentPanel;
import org.makerminds.intership.restaurantpoint.view.IView;
import org.makerminds.intership.restaurantpoint.view.admin.MenuManagerView;
import org.makerminds.intership.restaurantpoint.view.admin.RestaurantManagerView;

public class UserFeaturePanelCreator {

	private static Map<UserFeature,IView> userFeatureLabelMap;

	private static Map<UserFeature,IView> createUserFeatureIViewMap() {
		if(userFeatureLabelMap == null) {
			userFeatureLabelMap = new HashMap<>();
			//DEPARTMENTS Departments
			userFeatureLabelMap.put(UserFeature.MENU_ITEM_MANAGER, new ContentPanel());
			userFeatureLabelMap.put(UserFeature.MENU_MANAGER, new MenuManagerView());
			userFeatureLabelMap.put(UserFeature.ORDERS, new ContentPanel());
			userFeatureLabelMap.put(UserFeature.ORDERS_STATUS, new ContentPanel());
			userFeatureLabelMap.put(UserFeature.RESTAURANT_MANAGER, new RestaurantManagerView());
			userFeatureLabelMap.put(UserFeature.TABLE_MANAGER, new ContentPanel());
			userFeatureLabelMap.put(UserFeature.TABLE_ORDERS, new ContentPanel());
			userFeatureLabelMap.put(UserFeature.SIGN_OUT, new ContentPanel());
		}
		return userFeatureLabelMap;

	}
	public static IView getUserFeatureLabelResolver(UserFeature userFeature) {
		return createUserFeatureIViewMap().get(userFeature);
	}

}
