package org.makerminds.intership.restaurantpoint.view.admin;

import java.awt.Color;
import java.awt.EventQueue;
import java.awt.Font;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.sql.SQLException;
import java.util.List;

import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.table.DefaultTableModel;

import org.makerminds.intership.restaurantpoint.controller.MenuManagerController;
import org.makerminds.intership.restaurantpoint.dataprovider.DataProvider;
import org.makerminds.intership.restaurantpoint.dataprovider.DataProviderDatabase;
import org.makerminds.intership.restaurantpoint.model.Menu;
import org.makerminds.intership.restaurantpoint.model.Restaurant;
import org.makerminds.intership.restaurantpoint.utils.AbstractContentPanel;
public class MenuManagerView extends AbstractContentPanel {

	private JTextField menuDescriptionTextField;
	private JTextField menuNumberTextField;
	private JComboBox<Restaurant> restaurantSelector;

	private DefaultTableModel menuListTableModel;
	private JTable menuListTable;
	private String[] menuDataRow;

	private JFrame frame;

	private DataProvider dataProvider = new DataProvider();
	private MenuManagerController menuManagerController = new MenuManagerController();
	private DataProviderDatabase dataProviderDatabase = new DataProviderDatabase();

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			@Override
			public void run() {
				try {
					MenuManagerView window = new MenuManagerView();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	@Override
	public JPanel prepareView() {
		JPanel contentPanel = createContentPanel();
		//contentPanel.setLayout(null);
		MenuInputDataPanel(contentPanel);
		createButtons(contentPanel);
		contentPanel.add(RestaurantSelector());
		prepareMenuListDataTable(contentPanel);

		return contentPanel;
	}

	private void MenuInputDataPanel(JPanel contentPanel) {
		JLabel numberLabel = createLabel("Menu Number", 75);
		JLabel TypeLabel = createLabel("Menu Description", 15);
		menuNumberTextField = createTextField(100);
		menuDescriptionTextField = createTextField(40);

		contentPanel.add(numberLabel);
		contentPanel.add(menuNumberTextField);
		contentPanel.add(TypeLabel);
		contentPanel.add(menuDescriptionTextField);

	}

	private JTextField createTextField(int verticalPosition) {
		JTextField menuInputTextField = new JTextField();
		menuInputTextField.setBounds(20, verticalPosition, 200, 30);
		menuInputTextField.setFont(new Font("Arial", Font.PLAIN, 15));
		return menuInputTextField;
	}

	private JLabel createLabel(String message, int verticalPosition) {
		JLabel label = new JLabel(message);
		label.setBounds(20, verticalPosition, 200, 30);
		label.setFont(new Font("Arial", Font.PLAIN, 15));
		return label;
	}

	private void createButtons(JPanel contentPanel) {
		contentPanel.add(addButton());
		contentPanel.add(updateButton());
		contentPanel.add(deleteButton());

	}

	private JButton addButton() {
		JButton addButton = new JButton("Add");
		addButton.setBounds(30, 300, 100, 30);
		addButton.setBackground(Color.BLUE);
		addButton.setForeground(Color.white);
		return addButton;
	}

	private JButton updateButton() {
		JButton updateButton = new JButton("Update");
		updateButton.setBounds(150, 300, 100, 30);
		updateButton.setBackground(Color.BLUE);
		updateButton.setForeground(Color.white);

		return updateButton;
	}

	private JButton deleteButton() {
		JButton deleteButton = new JButton("Delete");
		deleteButton.setBounds(270, 300, 100, 30);
		deleteButton.setBackground(Color.RED);
		deleteButton.setForeground(Color.white);
		return deleteButton;
	}

	private JPanel RestaurantSelector() {
		JPanel comboBoxPanel = new JPanel();
		comboBoxPanel.setBounds(350, 30, 200, 40);
		comboBoxPanel.setLayout(null);
		comboBoxPanel.add(createComboBox());
		return comboBoxPanel;
	}

	private JComboBox<Restaurant> createComboBox() {
		restaurantSelector = new JComboBox<>();
		restaurantSelector.setBounds(0, 0, 200, 40);
		//createComboBoxData();
		restaurantSelector.addItemListener(new ItemListener() {

			@Override
			public void itemStateChanged(ItemEvent e) {
				// TODO Auto-generated method stub
				createMenuListTableModel();
			}
		});
		return restaurantSelector;
	}

	private void createComboBoxData() {
		restaurantSelector.removeAllItems();
		//lista e restauranteve o e zbarz 
		DataProvider dataProvider = new DataProvider();
		List<Restaurant> restaurants = dataProvider.getRestaurantList();
		for (Restaurant restaurant : restaurants) {
			restaurantSelector.addItem(restaurant);
		}

}
	private void prepareMenuListDataTable(JPanel contentPanel) {
		menuListTable = new JTable();
		JScrollPane scrollpane = new JScrollPane(menuListTable);
		scrollpane.setBounds(350, 90, 300, 150);
		contentPanel.add(scrollpane);
		createMenuListTableModel();
	}

	private void createMenuListTableModel() {
		menuListTableModel = new DefaultTableModel();
		String[] columnName = { "Number", "Menu Type" };
		menuListTableModel.setColumnIdentifiers(columnName);
		menuListTable.setModel(menuListTableModel);
		createMenuListTableData();
	}

	private void createMenuListTableData() {
		menuDataRow = new String[2];
		List<Menu> menuDataList = DataProvider.createMenuList();
		for (Menu menu : menuDataList) {
			menuDataRow[0] = menu.getMenuNumber();
			menuDataRow[1] = menu.getMenuDescription();
			menuListTableModel.addRow(menuDataRow);
		}
	}

	public DataProvider getDataProvider() {
		return dataProvider;
	}

	public void setDataProvider(DataProvider dataProvider) {
		this.dataProvider = dataProvider;
	}
}