package org.makerminds.intership.restaurantpoint.view.admin;

import java.awt.Color;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.List;

import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.table.DefaultTableModel;

import org.makerminds.intership.restaurantpoint.controller.RestaurantManagerController;
import org.makerminds.intership.restaurantpoint.dataprovider.DataProvider;
import org.makerminds.intership.restaurantpoint.dataprovider.DataProviderDatabase;
import org.makerminds.intership.restaurantpoint.model.Restaurant;
import org.makerminds.intership.restaurantpoint.utils.AbstractContentPanel;

public class RestaurantManagerView extends AbstractContentPanel {

	private JFrame frame;

	private JTextField restaurantNameTextField;
	private JTextField restaurantAddressTextField;
	private JComboBox<Restaurant> restaurantSelector;

	private DefaultTableModel restaurantTableModel;
	private JTable restaurantTable;
	private String[] restaurantDataRow;
	private DataProvider dataProvider = new DataProvider();

	private RestaurantManagerController restaurantManagerController = new RestaurantManagerController();

	@Override
	public JPanel prepareView() {
		JPanel contentPanel = createContentPanel();
		//contentPanel.setLayout(null);
		restaurantInputDataPanel(contentPanel);
		createButtons(contentPanel);
		contentPanel.add(createRestaurantManagerPanel());
		createRestaurantManagerPanel();
		contentPanel.add(restaurantSelector);
		prepareRestaurantData();
		return contentPanel;


}

	public JPanel createRestaurantManagerPanel() {
		JPanel contentPanel = new JPanel();
		contentPanel.setLayout(null);
		restaurantInputDataPanel(contentPanel);
		createButtons(contentPanel);
		createTable(contentPanel);
		return contentPanel;
	}

	private void restaurantInputDataPanel(JPanel contentPanel) {
		JLabel nameLabel = createLabel("Restaurant name", 15);
		JLabel addressLabel = createLabel("Restaurant address", 75);

		restaurantNameTextField = createTextField(40);
		restaurantAddressTextField = createTextField(100);

		contentPanel.add(nameLabel);
		contentPanel.add(restaurantNameTextField);
		contentPanel.add(addressLabel);
		contentPanel.add(restaurantAddressTextField);
	}

	private JTextField createTextField(int verticalPosition) {
		JTextField restaurantInputTextField = new JTextField();
		restaurantInputTextField.setBounds(20, verticalPosition, 200, 30);
		restaurantInputTextField.setFont(new Font("Arial", Font.PLAIN, 15));
		return restaurantInputTextField;
	}

	private JLabel createLabel(String message, int verticalPosition) {
		JLabel label = new JLabel(message);
		label.setBounds(20, verticalPosition, 200, 30);
		label.setFont(new Font("Arial", Font.PLAIN, 15));
		return label;
	}

	private void createButtons(JPanel contentPanel) {
		contentPanel.add(addButton());
		contentPanel.add(updateButton());
		contentPanel.add(deleteButton());

	}

	private JButton addButton() {
		JButton addButton = new JButton("Add");
		addButton.setBounds(30, 300, 100, 30);
		addButton.setBackground(Color.BLUE);
		addButton.setForeground(Color.white);
		addButton.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				Restaurant selectedRestaurant = (Restaurant) restaurantSelector.getSelectedItem();
				String[] restaurantData = new String[2];
				restaurantData[0] = restaurantNameTextField.getText();
				restaurantData[1] = restaurantAddressTextField.getText();
				if (areDataValid(restaurantData)) {
					restaurantManagerController.addRestaurant(selectedRestaurant, restaurantData);
					restaurantTableModel.addRow(restaurantData);
					clearTextFields();
				} else {
					JOptionPane.showMessageDialog(null, "Provide mandatory data to add new restaurant");
				}

			}
		});
		return addButton;
	}

	private JButton updateButton() {
		JButton updateButton = new JButton("Update");
		updateButton.setBounds(150, 300, 100, 30);
		updateButton.setBackground(Color.BLUE);
		updateButton.setForeground(Color.white);
		updateButton.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				Restaurant selectedRestaurant = (Restaurant) restaurantSelector.getSelectedItem();
				int SelectedRow = restaurantTable.getSelectedRow();
				if (SelectedRow != -1) {
					String name = (String) restaurantTable.getValueAt(SelectedRow, 2);
					String[] restaurantData = new String[2];
					restaurantData[0] = restaurantNameTextField.getText();
					restaurantData[1] = restaurantAddressTextField.getText();
					if (areDataValid(restaurantData)) {
						restaurantManagerController.updateRestaurant(selectedRestaurant, name, restaurantData);
						clearTextFields();
						createTableModel();
					} else {
						JOptionPane.showMessageDialog(null, "Please provide mandatory data to update a restaurant");
					}
				} else {
					JOptionPane.showMessageDialog(null, "Please select a row to edit.");
				}

			}
		});

		return updateButton;
	}

	private JButton deleteButton() {
		JButton deleteButton = new JButton("Delete");
		deleteButton.setBounds(270, 300, 100, 30);
		deleteButton.setBackground(Color.RED);
		deleteButton.setForeground(Color.white);
		deleteButton.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				Restaurant selectedRestaurant = (Restaurant) restaurantSelector.getSelectedItem();
				int SelectedRow = restaurantTable.getSelectedRow();
				if (SelectedRow != -1) {

					String name = (String) restaurantTable.getValueAt(SelectedRow, 2);
					restaurantManagerController.deleteRestaurant(selectedRestaurant, name);
					clearTextFields();
					createTableModel();

				} else {
					JOptionPane.showMessageDialog(null, "Please select a row to delete.");
				}

			}
		});
		return deleteButton;
	}

	private void createTable(JPanel contentPanel) {
		restaurantTable = new JTable();
		createTableModel();
		JScrollPane scrollPane = new JScrollPane(restaurantTable);
		scrollPane.setBounds(300, 40, 300, 150);
		contentPanel.add(scrollPane);
	}

	private void createTableModel() {
		restaurantTableModel = new DefaultTableModel();
		String[] columnName = { "Name", "Address" };
		restaurantTableModel.setColumnIdentifiers(columnName);
		prepareRestaurantData();
	}

	private void prepareRestaurantData() {
		// TODO Auto-generated method stub
		List<Restaurant> restaurantList = DataProviderDatabase.getRestaurantList();
		restaurantDataRow = new String[2];
		for (Restaurant restaurant : restaurantList) {
			restaurantDataRow[0] = restaurant.getName();
			restaurantDataRow[1] = restaurant.getAddress();
			restaurantTableModel.addRow(restaurantDataRow);
		}
		restaurantTable.setModel(restaurantTableModel);
	}

	private boolean areDataValid(String[] restaurantData) {
		return !restaurantData[0].equals("") && !restaurantData[1].equals("");
	}

	private void clearTextFields() {
		restaurantNameTextField.setText("");
		restaurantAddressTextField.setText("");
	}

	public DataProvider getDataProvider() {
		return dataProvider;
	}

	public void setDataProvider(DataProvider dataProvider) {
		this.dataProvider = dataProvider;
	}
}
